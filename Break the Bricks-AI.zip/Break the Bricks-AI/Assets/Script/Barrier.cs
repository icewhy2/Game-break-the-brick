﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Barrier : MonoBehaviour
{
    private NavMeshAgent agent;
    public GameObject enemy;
    public enum Barrier_Type
    {
        Normal,
        Prop_Life
    }
    public Barrier_Type currType;
    public GameObject LifeItemPrefab;
    public GameObject BrickParticlePrefab;
    public AudioSource brickAudio;
    // Start is called before the first frame update
    void Start()
    {
        agent = enemy.GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnCollisionEnter(Collision other)
    {
        if(currType == Barrier_Type.Prop_Life)
        {
            GameObject item = Instantiate(LifeItemPrefab);
            Vector3 pos = transform.position;
            pos.y -= 0.3f;//That controls the generation location
            item.transform.position = pos;
        }
        GameObject particle = Instantiate(BrickParticlePrefab);
        particle.transform.position = transform.position;
        brickAudio.Play();
        this.enabled = false;
        GM.instance.CheckLevelPassed();
        Destroy(gameObject);
        agent.acceleration += 5f;//Each time a ball is eaten, the enemy's tracking speed increases
    }
}
