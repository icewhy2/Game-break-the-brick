﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GM : MonoBehaviour
{
    public static GM instance;
    public int lifeTimes = 3;
    public Text Lives;
    public GameObject Victory;
    public bool isPlaying = false;
    private bool _isPassedLevel = false;
    public bool isPassedLevel
    {
        set
        {
            _isPassedLevel = value;
            if (_isPassedLevel)
            {
                isPlaying = false;
                Victory.SetActive(true);
            }
        }
        get
        {
            return _isPassedLevel;
        }
    } 
    void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void GameOver()
    {
        if (lifeTimes == 0) {
            string sceneName = SceneManager.GetActiveScene().name;
            SceneManager.LoadScene(sceneName);
        }
        else
        {
            ChangeLives(-1);
            isPlaying = false;
        }
    }

    public void CheckLevelPassed()
    {
        Barrier[] allBarriers = GameObject.FindObjectsOfType <Barrier>();
        bool tempPassedLevel = true;
        foreach (var item in allBarriers)
        {
            if(item.enabled == false)
            {
                continue;
            }
            tempPassedLevel = false;
        }
        isPassedLevel = tempPassedLevel;
    }
    
    public void ChangeLives(int step)
    {
        lifeTimes += step;
        Lives.text = "Lives:" + lifeTimes;
    }

    // Update is called once per frame
    void Update()
    {
        if (isPassedLevel)
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                if (SceneManager.GetActiveScene().name == "Level1")
                {
                    SceneManager.LoadScene("Level2");
                }
                if (SceneManager.GetActiveScene().name == "Level2")
                {
                    SceneManager.LoadScene("Level3");
                }
                if (SceneManager.GetActiveScene().name == "Level3")
                {
                    SceneManager.LoadScene("Level1");
                }
            }
        }
    }
}
