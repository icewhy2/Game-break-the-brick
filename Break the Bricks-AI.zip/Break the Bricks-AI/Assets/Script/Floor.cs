﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floor : MonoBehaviour
{
    public GameObject DeathParticlePrefab;
    public AudioSource deathAudio;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnCollisionEnter(Collision other)
    {
        Item item = other.gameObject.GetComponent<Item>();
        if (item != null)
        {
            Destroy(other.gameObject);
        }
        else{
            GameObject particle = Instantiate(DeathParticlePrefab);
            particle.transform.position = other.transform.position;
            deathAudio.Play();
            GM.instance.GameOver();
        }
    }
}
