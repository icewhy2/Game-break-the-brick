﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlidingPlate : MonoBehaviour
{
    public float xMax;
    public float xMin;
    public float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (GM.instance.isPassedLevel)
        {
            return;
        }
        float xx = Input.GetAxisRaw("Horizontal");
        if(xx != 0)
        {
            Vector3 pos = transform.position;
            pos.x += xx * Time.deltaTime * speed;
            pos.x = Mathf.Clamp(pos.x, xMin, xMax);
            transform.position = pos;
        }
    }
    void OnCollisionEnter(Collision other)
    {
        Item item = other.gameObject.GetComponent<Item>();
        if(item != null)
        {
            GM.instance.ChangeLives(1);
            Destroy(other.gameObject);
        }
    }
}
