﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sphere : MonoBehaviour
{
    private Rigidbody rb;
    public float speed;
    private const float RESET_Y = -3.9F;
    public Transform SlidingPlate;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!GM.instance.isPlaying)
        {
            Vector3 pos = transform.position;
            pos.x = SlidingPlate.position.x;
            pos.z = RESET_Y;
            transform.position = pos;
        }
        if (GM.instance.isPassedLevel)
        {
            return;
        }
        if (Input.GetMouseButtonDown(0) && !GM.instance.isPlaying) 
        {
            Vector3 speedNormalized = new Vector3(1f, 0, 1f).normalized;//初始的力
            rb.velocity = speedNormalized * speed;
            GM.instance.isPlaying = true;
        }
    }
    void OnCollisionExit(Collision other)
    {
        if (GM.instance.isPlaying)
        {
            Vector3 sp = rb.velocity.normalized;
            float angle = Mathf.Asin(sp.z / 1) * Mathf.Rad2Deg;//初始射出的角度
            if(angle >= 0 && angle < 10)
            {
                if(sp.x > 0)
                {
                    float yy = Mathf.Tan(10 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(1f, 0, yy).normalized;
                    sp = newVelocity;
                }
                else
                {
                    float yy = Mathf.Tan(10 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(-1f, 0, yy).normalized;
                    sp = newVelocity;
                }
            }
            else if(angle > 80 && angle <= 90)
            {
                if (sp.x > 0)
                {
                    float yy = Mathf.Tan(80 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(1f, 0, yy).normalized;
                    sp = newVelocity;
                }
                else
                {
                    float yy = Mathf.Tan(80 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(-1f, 0, yy).normalized;
                    sp = newVelocity;
                }
            }
            else if (angle <= 0 && angle > -10)
            {
                if (sp.x > 0)
                {
                    float yy = Mathf.Tan(-10 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(1f, 0, yy).normalized;
                    sp = newVelocity;
                }
                else
                {
                    float yy = Mathf.Tan(-10 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(-1f, 0, yy).normalized;
                    sp = newVelocity;
                }
            }
            else if (angle < -80 && angle >= -90)
            {
                if (sp.x > 0)
                {
                    float yy = Mathf.Tan(-80 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(1f, 0, yy).normalized;
                    sp = newVelocity;
                }
                else
                {
                    float yy = Mathf.Tan(-80 * Mathf.Deg2Rad);
                    Vector3 newVelocity = new Vector3(-1f, 0, yy).normalized;
                    sp = newVelocity;
                }
            }
            rb.velocity = sp * speed;
        }
    }
}
