﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FSM : MonoBehaviour
{
    public enum FSMstate//Finite state machine
    {
        None,
        Patrol,//Patrol
        Chase,//Chase
        Attack,//Attack
    }
    public FSMstate curState;//state
    public NavMeshAgent agent;//AI navigation grid variables
    public Transform Player;//The player
    public Transform patrol_point;//Initial position point
   // public GameObject enemy;//Enemy
    void Start()
    {
        curState = FSMstate.Patrol;//Set the initial state to patrol
        agent = this.GetComponent<NavMeshAgent>();//Or AI navigation components
    }

    void Update()
    {
        switch (curState)
        {
            case FSMstate.Patrol:
                StatePatrol();
                break;
            case FSMstate.Chase:
                StateChase();
                break;
            case FSMstate.Attack:
                StateAttack();
                break;
        }

    }

    void StatePatrol()
    {
        Debug.Log("Patroling");
        if (enemy_trigger.is_trigger == true) {
            curState = FSMstate.Chase;//If a player is detected, switch the state to the chase state
        }
        if (this.transform.position != patrol_point.position) {
            agent.SetDestination(patrol_point.position);//Navigate to the initial position
        }
    }

    void StateChase()
    {
        Debug.Log("Chasing");
        agent.SetDestination(Player.position);
        if (Vector3.Distance(this.transform.position, Player.position) <= 1)//Attack when the range is less than 0.1
        {
            curState = FSMstate.Attack;
        }

        if (Vector3.Distance(this.transform.position, Player.position)>=2)//When the distance exceeds 2, the enemy returns to the original point
        {
            curState = FSMstate.Patrol;
        }

    }

    void StateAttack()
    {
        Debug.Log("Attacking");
        if (Vector3.Distance(this.transform.position, Player.position) >= 1) {//Attack when the range is less than 1
            curState = FSMstate.Patrol;
            GM.instance.GameOver();//Player loses one life
            this.transform.position = patrol_point.position;


        }
    }

}

